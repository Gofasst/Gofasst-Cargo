GOFASST CARGO MANAGEMENT — STARTER VERSION

Files:
- index.html: app
- manifest.webmanifest: iPhone Home Screen app settings
- sw.js: offline cache

IMPORTANT:
To install as an iPhone Home Screen web app with offline support, these files must be hosted on an HTTPS website.
Then open the website in Safari on iPhone, tap Share, and choose Add to Home Screen.
Open it once while online so the app files are cached.

Records are saved in the browser on that device. Use Reports > Export backup regularly.
This starter app does not yet sync records between devices or to a cloud account.
