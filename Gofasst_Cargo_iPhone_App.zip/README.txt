GOFASST CARGO — iPhone Home Screen app package

WHAT IT DOES
- Customer shipment records, cargo kg, rate/kg, payment and balance
- Multiple container records and per-container revenue, expenses, break-even and gross profit
- Dashboard totals, editable default prices/costs
- CSV export and JSON backup/restore
- Offline use after the first successful load

IMPORTANT
This version stores data locally in Safari on the iPhone. It does not sync between devices or provide staff logins. Export a JSON backup regularly. If Safari website data is cleared, local records may be lost. This is a first version, not a hosted account-based system.

HOW TO INSTALL ON IPHONE
1. Publish the contents of this folder to an HTTPS static website. The files must be at the site root together (index.html, app.js, style.css, manifest.webmanifest, sw.js, icons).
2. Open the HTTPS website in Safari on your iPhone (not an in-app browser).
3. Tap Share, then Add to Home Screen. If shown, enable "Open as Web App", then tap Add.
4. Open Gofasst Cargo from the new Home Screen icon.
5. Open it once while online so the offline files can be cached.

ONE SIMPLE FREE HOSTING ROUTE: GITHUB PAGES
- Create/sign in to a GitHub account.
- Create a new public repository named gofasst-cargo.
- Upload all files from this folder to the repository root.
- In repository Settings > Pages, select Deploy from a branch, choose main and /(root), then Save.
- Wait for GitHub Pages to publish the HTTPS site. Open the published URL in Safari and follow the iPhone steps above.

BUSINESS CALCULATION
Revenue = sum of each shipment's kg × rate/kg.
Container gross profit = assigned shipment revenue − that container's shipping and other fees.
The dashboard expense total includes each entered container. If no container has been entered, it uses the default costs as a planning estimate.
Enter each customer's shipment under the correct container to make per-container reports accurate.
Check actual container payload limits and all applicable shipping/customs requirements.